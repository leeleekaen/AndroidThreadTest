package com.sky.androidthreadapp.onclicktest;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.sky.androidthreadapp.R;
import com.sky.androidthreadapp.mythread.ThreadTestActivity;

/**
 * Created by yuetu-develop on 2017/10/13.
 */

public class DownloadActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn_download = (Button) findViewById(R.id.btn_download);
        btn_download.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                downLoad();
            }
        });

    }

    public void downLoad(){
          //DownloadCallback作为构造器参数传入的形式
//        DownloadTask downloadTask = new DownloadTask(new DownloadCallback() {
//            @Override
//            public void result(final String result) {
//                runOnUiThread(new Runnable() {
//                    @Override
//                    public void run() {
//                        Toast.makeText(DownloadActivity.this,result,Toast.LENGTH_SHORT).show();
//                    }
//                });
//
//            }
//            @Override
//            public void error(int code) {
//
//            }
//        });
        //DownloadCallback通过set的方式传入
        DownloadTask downloadTask = new DownloadTask();
        // 传输一个DownloadCallback的实现类，new一个或者实现一个
        downloadTask.setDownloadCallback(new DownloadCallback() {
            @Override
            public void result(final String result) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(DownloadActivity.this,result,Toast.LENGTH_SHORT).show();
                    }
                });
            }

            @Override
            public void error(int code) {

            }
        });
        downloadTask.getInfo();
    }

    private static ThreadLocal<Integer> number = new ThreadLocal<Integer>(){

        @Override
        protected Integer initialValue() {
            return 1;
        }

        public void saveNumber(int newNumber){
            number.set(number.get() + newNumber);
        }

        public int getNumber(){
            return number.get();
        }
    };

}
