package com.sky.androidthreadapp.onclicktest;

import android.os.Looper;

/**
 * Created by yuetu-develop on 2017/10/13.
 */

public class DownloadTask {

    private DownloadCallback mDownloadCallback;

    public DownloadTask(){

    }

    public DownloadTask(DownloadCallback downloadCallback){
        this.mDownloadCallback = downloadCallback;
    }

    public void setDownloadCallback(DownloadCallback downloadCallback){
        this.mDownloadCallback = downloadCallback;
    }

    public void getInfo(){

        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                Looper.prepare();
                try {
                    Thread.sleep(1000);
                    mDownloadCallback.result("加载成功");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        thread.start();
//        new Thread(new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    Thread.sleep(1000);
//                    mDownloadCallback.result("加载成功");
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//            }
//        }).start();
    }

}
