package com.sky.androidthreadapp.onclicktest;

/**
 * Created by yuetu-develop on 2017/10/13.
 */

public interface DownloadCallback {

    void result(String result);

    void error(int code);

}
